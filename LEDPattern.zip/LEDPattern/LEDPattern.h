#ifndef LEDPattern_h
#define LEDPattern_h
#include"Arduino.h"
class LEDPattern
{
  public:
  LEDPattern(int led1,int led2,int led3,int led4);
  void pattern1();
  void pattern2();
  void pattern3();
  void pattern4();
  void pattern5();
  private:
  int _led1;
  int _led2;
  int _led3;
  int _led4;
  
};
#endif